name="Dead Money"
path="mod/DeadMoney"
supported_version="1.9.*"